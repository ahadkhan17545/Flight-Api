using FlightApi.Data;
using FlightApi.Repositories;
using FlightApi.Services;
using Microsoft.EntityFrameworkCore;
using System.Reflection;

/// <summary>
/// Entry point for the Flight API application.
/// Configures services and middleware
/// </summary>
var builder = WebApplication.CreateBuilder(args);
builder.Services.AddDbContext<FlightContext>(opt => opt.UseInMemoryDatabase("FlightsDb"));
builder.Services.AddScoped<IFlightRepository, FlightRepository>();
builder.Services.AddScoped<IFlightService, FlightService>();
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
    var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
    var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
    options.IncludeXmlComments(xmlPath);
});
var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}
else
{
    app.UseExceptionHandler("/error"); // Centralized exception handler
}

app.UseHttpsRedirection();
app.MapControllers();
app.Run();
